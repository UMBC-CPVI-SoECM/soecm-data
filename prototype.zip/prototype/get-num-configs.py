
def main() -> None:
    configs: int = 0
    files_checked: str = ""

    with open("out2.txt", 'r') as file:
        line: str = file.readline()

        while line:
            if "~~~ SOECM" in line:
                line = line.split()
                configs += int(line[6])
            elif "files checked" in line:
                files_checked = line

            line = file.readline()

    print(f"Checked {configs} configurations.")
     
    check_split: str = files_checked.split()[0]
    checked: int = int(check_split.split('/')[0])
    total_files: int = int(check_split.split('/')[1])
    print(f"Checked {checked}/{total_files} files.")
    print("Coverage: {:.2f}%".format((checked / total_files) * 100))

    return

if __name__ == "__main__":
    main()
