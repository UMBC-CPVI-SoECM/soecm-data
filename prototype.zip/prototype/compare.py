from copy import deepcopy
from json import dumps, loads

IMPORTANT_VULNS: list = [
    "strcpy",
    "sprintf",
    "strcat"
]

# read in vulnerabilities and line info as given by the dataset
def load_vulns_from_file(fname: str) -> dict:
    vulns: dict = {}
    with open(fname, 'r') as file:
        vulns = loads(file.read())

    return vulns

# return a dictionary consisting of the following key value pairs:
#   "vulnerable fxn": num_times_it_appears_in_the_set
def enumerate_vulns(dataset: dict) -> (dict, dict):
    parsed: dict = {}

    for vulns in dataset.values():
        for fxn in vulns.values(): 
            fxn = fxn.strip()
            
            if parsed.get(fxn) is None:
                parsed[fxn] = 0

            parsed[fxn] += 1

    filter_junk(parsed)
    return parsed

# the dataset describes some vulnerabilities as horrifically incompatible strings.
# this just takes strings such as
#   printf("(*pnt)->table,
# and converts them into just "sprintf" for enumeration purposes
def filter_junk(parsed: dict) -> None:
    # dictionary will change size while iterating
    keys = list(parsed.keys())

    for key in keys: 
        for vuln in IMPORTANT_VULNS:
            if vuln in key and vuln != key:
                parsed[vuln] += parsed[key]
                del parsed[key]

    return  

# parses the output of cppcheck into a dictionary similar to
# the one returned by enumerate_vulns()
def compare(dataset_vulns: dict, fname: str) -> (int, int):
    with open(fname, 'r') as file:
        i: int = 0
        num_errors: int = 0
        num_notes: int = 0

        line = file.readline()
        while line:
            if "error:" in line: num_errors += 1
            elif "note: " in line: num_notes += 1

            # dictionary size will change during iteration
            for key in list(dataset_vulns.keys()):
                stripped = line.strip()

                if key in stripped:
                    dataset_vulns[key] -= 1 

                    if dataset_vulns[key] <= 0:
                        del dataset_vulns[key]

                    continue

            i += 1
            if not (i % 5e4): print(f"{i} lines checked...")
            line = file.readline()

    return num_errors, num_notes 

def stats_and_write(original_vulns: dict, edited_vulns: dict, num_errors: int, num_notes: int, write_to: str="out/compared.json") -> None:
    print("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print(f"TOTAL NUMBER OF ERRORS DETECTED: {num_errors}")
    print(f"TOTAL NUMBER OF NOTES DETECTED: {num_notes}")

    total_original: int = sum(original_vulns.values())
    total_edited: int = sum(edited_vulns.values())

    percent = lambda v1, v2: (1 - (v1 / v2)) * 100
    fmt: str = "{:10}: {:6} / {:6} = {:.5f}%"
    for key in original_vulns:
        orig: int = original_vulns.get(key)
        edit: int = edited_vulns.get(key)
        if edit is None: continue

        print(fmt.format(key, edit, orig, percent(edit, orig)))

    print(fmt.format("TOTAL", total_edited, total_original, percent(total_edited, total_original)))

    with open(write_to, 'w') as file:
        file.write(dumps(edited_vulns, indent=2))

    return

def main() -> None:
    all_vulns: dict = load_vulns_from_file("data/dataset_vulnerabilities.json")
    vulns: dict = enumerate_vulns(all_vulns)
    vulns_copy: dict = deepcopy(vulns)
    num_errors, num_notes = compare(vulns, "data/cppcheck.out")
    stats_and_write(vulns_copy, vulns, num_errors, num_notes)
    
    return

if __name__ == "__main__":
    main()
